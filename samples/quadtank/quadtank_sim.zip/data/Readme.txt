The files in this directory will be copied to the ./data/ directory in the container.
